#!/usr/bin/env sh

dvisvgm --pdf --page=2- ../firamath-demo.pdf
