Map data (c) OpenStreetMap contributors, https://www.openstreetmap.org
Extracts created by BBBike, https://extract.bbbike.org
Maperitive by http://maperitive.net/

Please read the OSM wiki how to use SVG

  https://en.wikipedia.org/wiki/Scalable_Vector_Graphics
  https://wiki.openstreetmap.org/wiki/SVG


This SVG map was created on: Sat Jul 25 16:05:19 UTC 2020
Maperitive map style: cadastre
GPS rectangle coordinates (lng,lat): 2.28118,48.83645 x 2.30851,48.87207
Script URL: https://extract.bbbike.org?sw_lng=2.28118&sw_lat=48.83645&ne_lng=2.30851&ne_lat=48.87207&format=svg-cadastre.zip&city=Paris+Tour+Eiffel%2C+Avenue+Anatole+France%2C+Quartier+du+Gros-Caillou%2C+Paris%2C+%C3%8Ele-de-France%2C+France+m%C3%A9tropolitaine%2C+75007%2C+France&lang=fr
Name of area: Paris Tour Eiffel, Avenue Anatole France, Quartier


We appreciate any feedback, suggestions and a donation!
You can support us via PayPal or bank wire transfer.

  https://extract.bbbike.org/community.html

You can donate any free amount you want. We are happy for every donation,
for 5, 10, 20, or 50 Euro. Whatever you think the service is worth for you,
or you can afford. We need to raise 10 Euro (12 USD) by the end of the day or
300 Euro (350USD) per month to cover the server costs.
Your donation helps to pay for hosting the service. Many thanks!

thanks, Wolfram Schneider

--
BBBike professional plans: https://extract.bbbike.org/support.html
Planet.osm extracts: https://extract.bbbike.org
BBBike Map Compare: https://mc.bbbike.org
